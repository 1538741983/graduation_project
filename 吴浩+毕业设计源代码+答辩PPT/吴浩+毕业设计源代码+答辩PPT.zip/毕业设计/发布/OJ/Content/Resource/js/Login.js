﻿$(document).ready(function () {
    $("#loginPanel").load("/control/UserInfoHead.html");
    //$("#loginPanel").appendChild("");
    //$("#btn_login").click(function () {
    //    var username = $("#input_username").text;
    //    var password = $("#input_passward").text;
    //    alert(login(username, password));
    //});
});