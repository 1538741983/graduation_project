﻿namespace JudgeEngine
{
    public class JudgeSolution
    {
    }
}
