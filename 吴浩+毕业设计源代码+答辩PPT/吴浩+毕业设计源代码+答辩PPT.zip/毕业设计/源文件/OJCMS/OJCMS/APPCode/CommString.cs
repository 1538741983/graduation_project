﻿namespace OJCMS.APPCode
{
    public class CommString
    {
        public static string FunctionID = string.Empty;
    }
}