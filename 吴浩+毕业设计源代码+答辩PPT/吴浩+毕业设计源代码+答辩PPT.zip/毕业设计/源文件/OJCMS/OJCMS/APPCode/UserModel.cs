﻿namespace OJCMS.APPCode
{
    public class UserModel
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string PassWord { get; set; }
        public string A_ID { get; set; }
        public bool Ds { get; set; }
    }
}