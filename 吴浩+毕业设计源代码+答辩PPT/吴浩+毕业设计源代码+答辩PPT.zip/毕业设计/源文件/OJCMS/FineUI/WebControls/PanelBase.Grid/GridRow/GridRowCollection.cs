
#region Comment

/*
 * Project��    FineUI
 * 
 * FileName:    GridRowCollection.cs
 * CreatedOn:   2008-05-19
 * CreatedBy:   30372245@qq.com
 * 
 * 
 * Description��
 *      ->
 *   
 * History��
 *      ->
 * 
 * 
 * 
 * 
 */

#endregion

using System;
using System.Collections;
using System.Data;
using System.Collections.ObjectModel;
using System.Web.UI;


namespace FineUI
{
    /// <summary>
    /// �����пؼ�����
    /// </summary>
    public class GridRowCollection : Collection<GridRow>
    {


    }

}



