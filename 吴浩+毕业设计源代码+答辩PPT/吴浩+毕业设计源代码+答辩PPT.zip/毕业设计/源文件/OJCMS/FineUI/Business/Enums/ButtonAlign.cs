﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FineUI
{
    ///// <summary>
    ///// 按钮排列位置
    ///// </summary>
    //public enum ButtonAlign
    //{
    //    /// <summary>
    //    /// 
    //    /// </summary>
    //    Left,
    //    Right,
    //    Center
    //}

    ///// <summary>
    ///// 按钮排列位置名称
    ///// </summary>
    //internal static class ButtonAlignHelper
    //{
    //    public static string GetName(ButtonAlign type)
    //    {
    //        string result = String.Empty;

    //        switch (type)
    //        {
    //            case ButtonAlign.Left:
    //                result = "left";
    //                break;
    //            case ButtonAlign.Right:
    //                result = "right";
    //                break;
    //            case ButtonAlign.Center:
    //                result = "center";
    //                break;
    //        }

    //        return result;
    //    }
    //}
}